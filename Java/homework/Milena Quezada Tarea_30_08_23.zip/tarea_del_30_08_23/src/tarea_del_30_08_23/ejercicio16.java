/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea_del_30_08_23;

import java.util.Scanner;

/**
 *
 * @author monga
 */
public class ejercicio16 {
    public void todo(){
       String cadena4="java";
    for(int i = 0; i<cadena4.length();i++){
      System.out.println(cadena4.charAt(i));
    }
    
    //cargar una cadena por teclado y mostrar por pantalla cuantos espacios en blanco se ingresaron
    System.out.println("Contador de espacios");
     Scanner sz = new Scanner (System.in);
     System.out.println("Ingresa una cadena");
    String sz3 = sz.nextLine();
    int m=0;
   for(int i=0;i<sz3.length();i++){
       if(sz3.charAt (i)== ' '){
       
       m++;
       
   }
      
   }
     System.out.println("La cantidad de espacios es "+ m );
    
    
    }
}
