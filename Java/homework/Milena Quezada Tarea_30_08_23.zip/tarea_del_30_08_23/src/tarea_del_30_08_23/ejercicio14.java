/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea_del_30_08_23;

/**
 *
 * @author monga
 */
public class ejercicio14 {
   public void usuario(){
               String[][] usuariosContraseñas = {
            {"usuario1", "contraseña1"},
            {"usuario2", "contraseña2"},
            {"usuario3", "contraseña3"}
        };

        // Supongamos que ingresamos un usuario y contraseña
        String usuarioIngresado = "usuario2";
        String contraseñaIngresada = "contraseña2";

        // Validamos el usuario y contraseña ingresados
        boolean usuarioValido = false;

        for (String[] usuarioContraseña : usuariosContraseñas) {
            String usuario = usuarioContraseña[0];
            String contraseña = usuarioContraseña[1];

            if (usuario.equals(usuarioIngresado) && contraseña.equals(contraseñaIngresada)) {
                usuarioValido = true;
                break; // Si encontramos una coincidencia, salimos del bucle
            }
        }

        if (usuarioValido) {
            System.out.println("Acceso concedido. Bienvenido, " + usuarioIngresado + "!");
        } else {
            System.out.println("Acceso denegado. Usuario o contraseña incorrectos.");
        }
   } 
}
