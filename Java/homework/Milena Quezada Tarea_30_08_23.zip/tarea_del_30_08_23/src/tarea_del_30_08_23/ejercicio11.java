/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea_del_30_08_23;

/**
 *
 * @author monga
 */
public class ejercicio11 {
      public  void  numeros(){
           int[] numerosPrimos = new int[20]; // Creamos un array para almacenar los primeros 20 números primos
        int contador = 0; // Contador para llevar la cuenta de los números primos encontrados
        int numeroActual = 2; // Empezamos con el primer número primo, que es 2
        
        while (contador < 20) {
            if (esPrimo(numeroActual)) {
                numerosPrimos[contador] = numeroActual;
                contador++;
            }
            numeroActual++;
        }

        // Presentamos los números primos en la consola
        System.out.println("Los primeros 20 numeros primos son:");
        for (int i = 0; i < 20; i++) {
            System.out.print(numerosPrimos[i] + " ");
        }
    }

    // Función para verificar si un número es primo
    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}
