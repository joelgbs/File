/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea_del_30_08_23;

/**
 *
 * @author monga
 */
public class ejrcicio13 {
    public void pares(){
        int[] numerosPares = new int[51]; // Creamos un array para almacenar los números pares, 51 porque hay 51 números pares entre 100 y 200
        int contador = 0; // Contador para llevar la cuenta de los números pares

        for (int i = 100; i <= 200; i++) {
            if (i % 2 == 0) { // Verificamos si el número es par
                numerosPares[contador] = i;
                contador++;
            }
        }

        // Presentamos los números pares en la consola
        System.out.println("Los números pares entre 100 y 200 son:");
        for (int i = 0; i < contador; i++) {
            System.out.print(numerosPares[i] + " ");
        }
    }
}
