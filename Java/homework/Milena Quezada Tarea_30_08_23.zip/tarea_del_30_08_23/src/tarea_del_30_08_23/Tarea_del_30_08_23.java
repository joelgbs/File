/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea_del_30_08_23;

import java.util.Scanner;

/**
 *
 * @author monga
 */
public class Tarea_del_30_08_23 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ejercicio11 a= new ejercicio11();
        ejercicio12 b= new ejercicio12();
        ejrcicio13 c= new ejrcicio13();
        ejercicio14 d= new ejercicio14();
        ejercicio15 e= new ejercicio15();
        ejercicio16 f= new ejercicio16();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        while (true) {
            System.out.println("\n----------------------Menu------------------------");
            System.out.println("1. Opcion array con los 20 primeros numeros primos");
            System.out.println("2. Opcion contar caracteres de una frase");
            System.out.println("3. Opcion numeros pares del 100 al 200");
            System.out.println("4. Opcion validar usuarios y contrasenias");
            System.out.println("5. Opcion array que contenga nombres de animales");
            System.out.println("6. Opcion ejercicio con todo lo aprendido");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opcion (1-7): ");

            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("\nSeleccionaste la Opcion 1");
                     a.numeros();
                    break;
                case 2:
                    System.out.println("\nSeleccionaste la Opcion 2");
                     b.cadena();
                    break;
                case 3:
                    System.out.println("\nSeleccionaste la Opcion 3");
                    c.pares();
                    break;
                case 4:
                    System.out.println("\nSeleccionaste la Opcion 4");
                    d.usuario();
                    break;
                case 5:
                    System.out.println("\nSeleccionaste la Opcion 5");
                    e.nombres();
                    break;
                case 6:
                    System.out.println("\nSeleccionaste la Opcion 6");
                    f.todo();
                    break;
                case 7:
                    System.out.println("Saliendo del programa. ¡Hasta luego!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Opcion no valida. Por favor, seleccione una opcion valida (1-7).");
                    break;
            }
        }
    


    }
    
    
}
