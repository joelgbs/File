/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea_del_30_08_23;

/**
 *
 * @author monga
 */
public class ejercicio15 {
    public void nombres(){
     String[] nombresMascotas = {
            "Max",
            "Luna",
            "Buddy",
            "Daisy",
            "Rocky",
            "Molly",
            "Charlie",
            "Lucy",
            "Cooper",
            "Bella"
        };

        // Mostramos los nombres de las mascotas en la consola
        System.out.println("Nombres de las mascotas:");

        for (String nombre : nombresMascotas) {
            System.out.println(nombre);
        }
    }
}
