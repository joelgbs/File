/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea_del_30_08_23;

/**
 *
 * @author monga
 */
public class ejercicio12 {
    public void cadena(){
        String cadena = "Unidad educativa uyumbicho hoja de control diario";
        int[] contadorCaracteres = new int[26]; // Creamos un array para contar las letras del alfabeto

        // Convertimos la cadena a minúsculas para que el conteo sea insensible a mayúsculas/minúsculas
        cadena = cadena.toLowerCase();

        // Recorremos la cadena para contar los caracteres
        for (int i = 0; i < cadena.length(); i++) {
            char caracter = cadena.charAt(i);
            if (Character.isLetter(caracter)) { // Verificamos si es una letra
                int indice = caracter - 'a'; // Calculamos el índice en el array
                contadorCaracteres[indice]++; // Incrementamos el contador correspondiente
            }
        }

        // Imprimimos los resultados
        for (char letra = 'a'; letra <= 'z'; letra++) {
            int indice = letra - 'a';
            if (contadorCaracteres[indice] > 0) {
                System.out.println(letra + ": " + contadorCaracteres[indice] + " veces");
            }
    }
    }
}
